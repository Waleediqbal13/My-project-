use microave
select * from booking
delete from booking where id like 'w%'

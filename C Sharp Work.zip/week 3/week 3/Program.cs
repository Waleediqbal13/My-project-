﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace week_3
{
    class Program
    {
        static void Main(string[] args)
        {
            person p = new teacher();
            p.setdata();
            p.getdata();
            Console.ReadKey();
            

        }
    }

    class person
    {
        string id, name, cont;
        public virtual void setdata()
        {
            Console.Write("Enter Person Id :");
            id = Console.ReadLine();
            Console.Write("Enter Person Name :");
            name = Console.ReadLine();
            Console.Write("Enter Person Contact Number :");
            cont = Console.ReadLine();
        }
        public virtual void getdata()
        {
            Console.Write("\nPerson Information"+"\n"+id+"       "+name+"      "+cont);

        }
    }
    class student : person
    {
        string reg, degree, section, semseter;
        public override void setdata()
        {
            base.setdata();
            Console.Write("Enter Student Arid No :");
            reg = Console.ReadLine();
            Console.Write("Enter Student Degree :");
            degree = Console.ReadLine();
            Console.Write("Enter Student Section :");
            section = Console.ReadLine();
            Console.Write("Enter Student Semseter :");
            semseter = Console.ReadLine();
        }
        public override void getdata()
        {
            base.getdata();
            Console.Write("\nStudent Information\n" +reg + "     " + degree + "     " + section + "   " + semseter);
        }
    }
    class teacher : student
    {
        string tname,qua;
        int salary;
        public override void setdata()
        {
            base.setdata();
            Console.Write("Enter Teacher Name:");
            tname = Console.ReadLine();
            Console.Write("Enter Teacher Qualification:");
            qua = Console.ReadLine();
            Console.Write("Enter Teacher Salary:");
            salary = int.Parse(Console.ReadLine());
        }
        public override void getdata()
        {
            base.getdata();
            Console.Write("\nTeacher Information\n" + tname +"      " + qua + "    " + salary);
        }

    }

}

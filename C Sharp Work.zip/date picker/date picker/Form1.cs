﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace date_picker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double year = double.Parse(dateTimePicker1.Value.Year.ToString());
            double year1 = double.Parse(dateTimePicker2.Value.Year.ToString());
            double day = double.Parse(dateTimePicker1.Value.Day.ToString());
            double day1 = double.Parse(dateTimePicker2.Value.Day.ToString());
            double tday = day1 - day;
            double ty = year1 - year;
            double month = double.Parse(dateTimePicker1.Value.Month.ToString());
            double mon = double.Parse(dateTimePicker2.Value.Month.ToString());

            double tm = mon - month;
            textBox1.Text = "you are " +"    "+ ty.ToString() +"   " + "year" +"    "+ tm + "months"+"      "+tday+"days";


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

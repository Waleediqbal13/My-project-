﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMBOBOXEXAMPLE
{
    public partial class icecreamapp : Form
    {
        int pri;
        int subt;
        int tax, total;
        public icecreamapp()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void icecreamapp_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          if(checkBox1.Checked)
            {
                pri = 20;
            }
          
                if (checkBox2.Checked)
            {
                 pri= pri+50;
            }
          
                if (checkBox3.Checked)
            {
                pri =pri+ 75;
            }
            if (radioButton1.Checked)
            {
                pri = pri+15;
            }

            if (radioButton2.Checked)
            {
                pri =pri+ 35;
            }

            if (radioButton3.Checked)
            {
               pri = pri+45;
            }
            
            tax = pri * 6 / 100;
            total = pri + tax;
            textBox1.Text = pri.ToString();
            textBox2.Text = tax.ToString();
            textBox3.Text = total.ToString();
            if(checkBox1.Checked==false)
            {
                pri = pri-20;
            }
          else
            if (checkBox2.Checked == false)
            {
                pri = pri-50;
            }
            else
                if (checkBox3.Checked == false)
            {
                pri = pri -75;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

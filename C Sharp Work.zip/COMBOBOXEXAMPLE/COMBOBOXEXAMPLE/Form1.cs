﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMBOBOXEXAMPLE
{
    public partial class Form1 : Form
    {
     
      string add;
        int i;        
        public Form1()
        {
            InitializeComponent();
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        private void button5_Click(object sender, EventArgs e)
        {
            add = textBox1.Text;
            comboBox1.Items.Add(add);
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex==-1)
            {
                MessageBox.Show("please select employee");
            }
            else
            {
                MessageBox.Show("selected item ="+comboBox1.SelectedItem.ToString());
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("index =" + comboBox1.SelectedIndex.ToString());
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex !=-1)
            {
                comboBox1.Items.RemoveAt(comboBox1.SelectedIndex);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == string.Empty)
            {
                if (radioButton1.Checked)
                {
                    i = int.Parse(textBox2.Text);
                    comboBox1.Items.RemoveAt(i);
                    MessageBox.Show("Remove");

                }
                else
                    if (radioButton2.Checked)
                {
                    comboBox1.Items.Remove(textBox2.Text);
                    MessageBox.Show("Remove");
                }
            }
            }
        }
    }


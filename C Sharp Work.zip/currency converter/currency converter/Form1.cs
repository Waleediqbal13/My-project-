﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace currency_converter
{
    public partial class Form1 : Form
    {
        double amt, phil, euro, pkr,tot,tot1,tot2;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            amt = Double.Parse(textBox2.Text);
            phil = 43.55;
            if(radioButton1.Checked)
            {
                tot = amt * phil;
                MessageBox.Show(tot.ToString());
            }
            else
                if(radioButton2.Checked)
            {
                euro = 56.77;
                tot1 = amt * euro;
                MessageBox.Show(tot1.ToString());
            }
            else
                if(radioButton3.Checked)
            {
                pkr = 1.00;
                tot2 = amt * pkr;
                MessageBox.Show(tot2.ToString());
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace week_5_tahir_lab
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<int> q = new Queue<int>();
            q.Enqueue(23);
            q.Enqueue(24);
            q.Enqueue(25);
            q.Enqueue(26);
            q.Enqueue(27);
            q.Enqueue(28);

            Console.Write(q.Dequeue());

            Console.ReadKey();

        }
    }
}

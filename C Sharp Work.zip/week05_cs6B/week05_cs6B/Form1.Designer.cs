﻿namespace week05_cs6B
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdred = new System.Windows.Forms.RadioButton();
            this.rdblue = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.purple = new System.Windows.Forms.RadioButton();
            this.reyellow = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rdred
            // 
            this.rdred.AutoSize = true;
            this.rdred.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.rdred.Location = new System.Drawing.Point(46, 36);
            this.rdred.Name = "rdred";
            this.rdred.Size = new System.Drawing.Size(48, 17);
            this.rdred.TabIndex = 0;
            this.rdred.Text = "RED";
            this.rdred.UseVisualStyleBackColor = false;
            this.rdred.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rdblue
            // 
            this.rdblue.AutoSize = true;
            this.rdblue.Location = new System.Drawing.Point(116, 36);
            this.rdblue.Name = "rdblue";
            this.rdblue.Size = new System.Drawing.Size(53, 17);
            this.rdblue.TabIndex = 1;
            this.rdblue.Text = "BLUE";
            this.rdblue.UseVisualStyleBackColor = true;
            this.rdblue.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.reyellow);
            this.groupBox1.Controls.Add(this.purple);
            this.groupBox1.Controls.Add(this.rdred);
            this.groupBox1.Controls.Add(this.rdblue);
            this.groupBox1.Location = new System.Drawing.Point(30, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(213, 116);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Radio Button";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // purple
            // 
            this.purple.AutoSize = true;
            this.purple.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.purple.Location = new System.Drawing.Point(125, 68);
            this.purple.Name = "purple";
            this.purple.Size = new System.Drawing.Size(55, 17);
            this.purple.TabIndex = 2;
            this.purple.Text = "Purple";
            this.purple.UseVisualStyleBackColor = false;
            this.purple.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // reyellow
            // 
            this.reyellow.AutoSize = true;
            this.reyellow.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.reyellow.Location = new System.Drawing.Point(46, 68);
            this.reyellow.Name = "reyellow";
            this.reyellow.Size = new System.Drawing.Size(56, 17);
            this.reyellow.TabIndex = 3;
            this.reyellow.Text = "Yellow";
            this.reyellow.UseVisualStyleBackColor = false;
            this.reyellow.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(261, 156);
            this.Controls.Add(this.groupBox1);
            this.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rdred;
        private System.Windows.Forms.RadioButton rdblue;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton reyellow;
        private System.Windows.Forms.RadioButton purple;
    }
}


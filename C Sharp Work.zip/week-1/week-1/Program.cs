﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace week_1
{
    class Program
    {
        static void Main(string[] args)
        {
          
            string name, reg, sect, sems;
            float gpa;
            Console.Write("Enter Name :");
            name = Console.ReadLine();
            Console.Write("Enter Arid No :");
            reg= Console.ReadLine();
            Console.Write("Enter Section :");
            sect = Console.ReadLine();
            Console.Write("Enter Semster :");
            sems = Console.ReadLine();
            Console.Write("Enter Gpa :");
            gpa = float.Parse(Console.ReadLine());

            Console.Write("\n"+name+"   "+reg+"   "+sect+"   "+sems+"    "+gpa);

            int[] num = new int[5];
            int search;

            for (int i = 0; i < num.Length; i++)
            {
                Console.Write("\nEnter Number  " + (i + 1) + ":");
                num [i]= int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < num.Length; i++)
            {
                Console.Write("Number :" + num[i]);
                Console.Write("\n Number Search From Array :");
                search = int.Parse(Console.ReadLine());

                if (num[i] == search)
                {
                    Console.Write("Number :" + search);
                }
            }
          
                Console.ReadKey();

        }
    }
}

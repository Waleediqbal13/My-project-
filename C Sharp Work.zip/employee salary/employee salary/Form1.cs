﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace employee_salary
{
    public partial class Form1 : Form
    {
        string sername= "Data Source=(local);Initial Catalog=employee;Integrated Security=True";
        SqlConnection conn;
        SqlCommand comm;
        SqlDataAdapter sda;
        DataTable dt;
        float ba, bon, tot, tax, net;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnconnect_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(sername);
            if(conn.State==ConnectionState.Closed)
            {
                
                MessageBox.Show("connect successfully........");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            ba = float.Parse(textBox1.Text);
            bon = float.Parse(textBox2.Text);
            tot = ba + bon;
            textBox3.Text = tot.ToString();
            tax = tot * 5 / 100;
            textBox4.Text = tax.ToString();
            net = tot - tax;
            textBox5.Text = net.ToString();
            
            
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}

use student
select * from stdrecord
delete from stdrecord
